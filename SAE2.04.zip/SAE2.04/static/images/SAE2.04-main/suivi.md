## Vendredi 21 janvier 2020
- Valentin Mougenot : MCD et fichier sql
- Julien Mourcely, David Monnier, Dorian Lacreuse : Téléchargement images et jeu de test sql
