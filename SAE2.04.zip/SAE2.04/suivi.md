## Vendredi 21 janvier 2022
- Valentin Mougenot : MCD et fichier sql
- Julien Mourcely, David Monnier, Dorian Lacreuse : MCD, Téléchargement images pour jeu de test, création du compte github
## Mardi 25 janvier 2022
 - Valentin Mougenot : Début du jeu de test sql
 - David Monnier et Julien Mourcely : création compte python anywhere, base du flask
 - Dorian Lacreuse : ABS
## Vendredi 28 Janvier 2022:
 - Valentin Mougenot : fin jeu de test sql
 - David Monnier et Julien Mourcely : fin du téléchargement images et modèle pour jeu de test, information sur toutes les tâches à implémenter
 - Dorian Lacreuse : ABS
 - Valentin, David, Julien : début de mise en ligne sur python anywhere
 ## Jeudi 2 février et vendredi 3 février
  - Valentin Mougenot : suite du flask et fin du MCD
  - Julien Mourcely : fin du MCD
  - David Monnier : rapport MCD et cahier des charges
  - Dorian Lacreuse : fin du MCD et rapport MCD
