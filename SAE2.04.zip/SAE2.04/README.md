# Dépot github pour la SAE 2.04
### Valentin Mougenot (Référent), David Monnier, Julien Mourcely, Dorian Lacreuse

* SAE2.04/ -> Le code source du projet
* mcd_projet.loo -> Le mcd du projet
* bdd_sql_v1.sql -> Le script sql du projet
